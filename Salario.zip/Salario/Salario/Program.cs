﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Salario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Faça um algoritmo que leia o valor do salário minimo e o valor do sálario de um usuário, calcule quantos salários minimos esse usuário ganhar e imprima
            na tela o resultador. (Base para o Salário mínimo R$ 1.518,00)*/
            double salario, minimo, total;
            minimo = 1518;
          
            Console.WriteLine("Digite o seu salário: ");
            salario = double.Parse(Console.ReadLine());
            total = salario / minimo;
            Console.WriteLine("Você ganha " + total + " Salarios minimos ");
             
             

             











            }
        }
    }
