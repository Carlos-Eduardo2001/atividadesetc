﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Subtração
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number, number2, soma;
        Console.Write("Digite o primeiro número: ");
            number = int.Parse(Console.ReadLine());
            Console.Write("Digite o segundo número: ");
            number2 = int.Parse(Console.ReadLine());
            soma = number - number2;
            Console.WriteLine("O resultado da subtração é; " + soma);








        }
    }
}
