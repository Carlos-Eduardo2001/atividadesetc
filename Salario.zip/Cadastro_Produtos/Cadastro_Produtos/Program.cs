﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro_Produtos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Crie um algoritimo para cadastro de produto: Código, Fabricante, categoria, Preço, estoque, valor total em estoque
            int codigo, estoque;
            string fabricante, categoria;
            double preco, total;
            Console.WriteLine("Digite o código: ");
            codigo = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o Fabricante: ");
            fabricante = Console.ReadLine();
            Console.WriteLine("Digite a Categoria: ");
            categoria = Console.ReadLine();
            Console.WriteLine("Digite o preço: ");
            preco = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o estoque: ");
            estoque = int.Parse(Console.ReadLine());
            total = preco * estoque;
                Console.WriteLine("O valor em estoque é " + total);









        }
    }
}
