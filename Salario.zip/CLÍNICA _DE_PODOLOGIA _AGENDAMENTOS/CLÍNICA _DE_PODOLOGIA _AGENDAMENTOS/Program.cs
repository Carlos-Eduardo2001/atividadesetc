﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLÍNICA__DE_PODOLOGIA__AGENDAMENTOS
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
