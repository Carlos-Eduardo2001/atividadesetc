﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fabrica
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Uma fábrica tem uma linha de produção capaz de produzir 400 peças/dia. Um funcionário controla a qualidade, cadastrando quantas peças e o seu estado (aprovado ou reprovado). Criar um programa para cadastrar o controle de qualidade e imprimir o total de peças aprovadas e reprovadas no final do dia. 
            int contador, numPecas, aprovados, reprovados;
        string estado;
            contador = 1;
            reprovados = 0;
            aprovados = 0;
            while (contador <= 40)
            {
                Console.WriteLine("Digite o número da " + contador + " peça: ");
                numPecas = int.Parse(Console.ReadLine());

                Console.WriteLine("Digite se a peça está aprovada ou reprovada(a para aprovada / r para reprovada): ");
                estado = Console.ReadLine();

                if(estado == "a")
                {
                    aprovados++;
                }
                else
                {
                    reprovados++;
                }
                contador++;
                Console.Clear();
                }
            Console.WriteLine("Total de peças aprovados: " + aprovados);
            Console.WriteLine("Total de peças reprovados: " + reprovados);
            
        
          


           







        }
    }
}
