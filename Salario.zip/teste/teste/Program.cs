﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Cadastro_de_Bandas

{

    internal class Program
    {

        /*

         

        se / enquanto / para /caso 

        if / while / for / switch


        Crie um sistema de cadastro de Álbuns de um artista / banda em que será possivel cadastrar um número X de músicas informada pelo usuário.

        Crie um menu de opção para isso.


         */
        static void Main(string[] args)

        {

            int opcao = 0;


            while (opcao != 4)



                Console.Clear();        //Limpa a telaConsole.ForegroundColor = ConsoleColor.Yellow;

            Console.WriteLine(@"

░█████╗░░█████╗░███╗░░██╗████████╗██████╗░░█████╗░██╗░░░░░███████╗  ██████╗░███████╗

██╔══██╗██╔══██╗████╗░██║╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░██╔════╝  ██╔══██╗██╔════╝

██║░░╚═╝██║░░██║██╔██╗██║░░░██║░░░██████╔╝██║░░██║██║░░░░░█████╗░░  ██║░░██║█████╗░░

██║░░██╗██║░░██║██║╚████║░░░██║░░░██╔══██╗██║░░██║██║░░░░░██╔══╝░░  ██║░░██║██╔══╝░░

╚█████╔╝╚█████╔╝██║░╚███║░░░██║░░░██║░░██║╚█████╔╝███████╗███████╗  ██████╔╝███████╗

░╚════╝░░╚════╝░╚═╝░░╚══╝░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░╚══════╝╚══════╝  ╚═════╝░╚══════╝


██████╗░░█████╗░███╗░░██╗██████╗░░█████╗░░██████╗

██╔══██╗██╔══██╗████╗░██║██╔══██╗██╔══██╗██╔════╝

██████╦╝███████║██╔██╗██║██║░░██║███████║╚█████╗░

██╔══██╗██╔══██║██║╚████║██║░░██║██╔══██║░╚═══██╗

██████╦╝██║░░██║██║░╚███║██████╔╝██║░░██║██████╔╝

╚═════╝░╚═╝░░╚═╝╚═╝░░╚══╝╚═════╝░╚═╝░░╚═╝╚═════╝░");


            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Blue;

            Console.WriteLine("1 - Cadastrar Album da Banda");

            Console.WriteLine("2 - Cadastrar Album do Artista"); // Ano, Nome Artista, Quantidade de Album, Quantidade de VendasConsole.WriteLine("3 - Cadastrar Músicas"); // Digitar a quantidade de músicas (Nome da música, Duração, Premiação)Console.WriteLine("4 - Sair do programa");

            Console.WriteLine(" ----> ");

            Console.ResetColor();

            opcao = int.Parse(Console.ReadLine());


            switch (opcao)

            {

                case 1:


                    Cadastro_Bandas();


                    break;

                case 2:

                    break;

                case 3:

                    break;

                case 4:

                    Console.Clear();

                    Console.WriteLine(" Saindo do programa!! Tchau Tchau ! !   :)");

                    break;

            }













        }


        static void Cadastro_Bandas()

        {

            string nomeBanda, nomeAlbum;

            int qtdMusica;


            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Yellow;

            Console.WriteLine(@"

░█████╗░░█████╗░██████╗░░█████╗░░██████╗████████╗██████╗░░█████╗░  ██████╗░███████╗

██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔══██╗  ██╔══██╗██╔════╝

██║░░╚═╝███████║██║░░██║███████║╚█████╗░░░░██║░░░██████╔╝██║░░██║  ██║░░██║█████╗░░

██║░░██╗██╔══██║██║░░██║██╔══██║░╚═══██╗░░░██║░░░██╔══██╗██║░░██║  ██║░░██║██╔══╝░░

╚█████╔╝██║░░██║██████╔╝██║░░██║██████╔╝░░░██║░░░██║░░██║╚█████╔╝  ██████╔╝███████╗

░╚════╝░╚═╝░░╚═╝╚═════╝░╚═╝░░╚═╝╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░  ╚═════╝░╚══════╝


██████╗░░█████╗░███╗░░██╗██████╗░░█████╗░░██████╗

██╔══██╗██╔══██╗████╗░██║██╔══██╗██╔══██╗██╔════╝

██████╦╝███████║██╔██╗██║██║░░██║███████║╚█████╗░

██╔══██╗██╔══██║██║╚████║██║░░██║██╔══██║░╚═══██╗

██████╦╝██║░░██║██║░╚███║██████╔╝██║░░██║██████╔╝

╚═════╝░╚═╝░░╚═╝╚═╝░░╚══╝╚═════╝░╚═╝░░╚═╝╚═════╝░");


            Console.ResetColor();


            Console.WriteLine("Digite o Nome da Banda: ");

            nomeBanda = Console.ReadLine();


            Console.WriteLine("Digite o Nome da Album: ");

            nomeAlbum = Console.ReadLine();


            Console.WriteLine("Digite o Número de Músicas: ");

            qtdMusica = int.Parse(Console.ReadLine());




            Console.WriteLine("\n Cadastro realizado com Sucesso ! ! !");

            Console.WriteLine("\n" + nomeBanda);

            Console.WriteLine("\n" + nomeAlbum);

            Console.WriteLine("\n" + qtdMusica);



            Thread.Sleep(1500);

        }




    }

}