﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Divisão
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("Digite seu número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite seu segundo número: ");
            n2 = int.Parse(Console.ReadLine());
            Console.WriteLine("A divisão do número é igual a: " + n1 / n2);








        }
    }
}
